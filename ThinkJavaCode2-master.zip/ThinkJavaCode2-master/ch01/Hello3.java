public class Hello3 {

    public static void main(String[] args) {
        System.out.print("Hello!\nHow are you doing?\n");
        System.out.println("She said \"Hello!\" to me.");
    }

}
