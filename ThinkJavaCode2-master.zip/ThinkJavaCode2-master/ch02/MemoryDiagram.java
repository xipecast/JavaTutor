public class MemoryDiagram {

    public static void main(String[] args) {
        int a = 5;
        int b = a;     // a and b are now equal
        a = 3;         // a and b are no longer equal
        int c = 0;
    }

}
