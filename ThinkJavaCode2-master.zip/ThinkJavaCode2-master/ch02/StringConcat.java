public class StringConcat {

    public static void main(String[] args) {
        System.out.println(1 + 2 + "Hello");
        // the output is 3Hello

        System.out.println("Hello" + 1 + 2);
        // the output is Hello12

    }

}
